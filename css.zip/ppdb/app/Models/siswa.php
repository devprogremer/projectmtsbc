<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class siswa extends Model
{
    protected $table = 'siswa';
//   public function ayah()
// {
//     return $this->belongsTo(ayah::class, 'id_ayah');
// }

// public function ibu()
// {
//   return $this->belongsTo(ibu::class, 'id_ibu');
// }
}
