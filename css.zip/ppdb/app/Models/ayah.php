<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ayah extends Model
{

      protected $table = 'ayah';
}
