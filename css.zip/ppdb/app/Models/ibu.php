<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ibu extends Model
{
    protected $table = 'ibu';
}
