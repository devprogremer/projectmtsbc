   <script src="<?php echo e(url('sbadmin/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('sbadmin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('sbadmin/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('sbadmin/js/sb-admin-2.min.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(url('sbadmin/vendor/chart.js/Chart.min.js')); ?>"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(url('sbadmin/js/demo/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(url('sbadmin/js/demo/chart-pie-demo.js')); ?>"></script>
<?php /**PATH C:\Users\SYARIF FADILLA\Documents\PPDB_SMP\resources\views/includes/script.blade.php ENDPATH**/ ?>