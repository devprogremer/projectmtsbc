<?php $__env->startPush('style'); ?>
<link href="<?php echo e(asset('sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('pesan')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h4><i class="icon fa fa-check"></i>Success</h4>
    <?php echo e(session('pesan')); ?>

</div>
<?php endif; ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>

    </div>
    <div>
        <div class="text-end mt-2 mt-sm-0">
            
            <button class="btn btn-info waves-effect waves-light mb-4" onclick="printContent('div1')"><i
                class="fa fa-print"> PRINT</i></button>
            
        </div>
    </div>
    <!-- Content Row -->


    <div class="row mt-5" id="div1">
        <div class="col-12">
            <h1>Data Peserta PPDB</h1>
        </div>
        <div class="col-12">
            <div class="row-6">
            <div class="card mt-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>Asal Sekolah</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1 ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td><?php echo e($item->nama_siswa); ?></td>
                                    <td><?php echo e($item->asal_sekolah); ?></td>>
                                    <td>
                                        <?php if($item->status == 'MENUNGGU'): ?>
                                            <div class="font-weight-bold text-warning">MENUNGGU</div>
                                        <?php endif; ?>
                                        <?php if($item->status == 'DITOLAK'): ?>
                                            <div class="font-weight-bold text-danger">DITOLAK</div>
                                        <?php endif; ?>
                                        <?php if($item->status == 'DITERIMA'): ?>
                                            <div class="font-weight-bold text-success">DITERIMA</div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="admin/detail/<?php echo e($item ->id); ?>" class="btn btn-primary">
                                            Detail
                                        </a>
                                    <?php if($item -> status == 'DITERIMA'): ?>
                                       <a href="https://wa.me/<?php echo e($item->no_telp); ?>?text=Hallo%20 *<?php echo e($item->nama_siswa); ?>*

                                       Saya Admin Dari MTs Bina Cendekia Cirebon Ingin memberi tahu bahwa pendaftaran anda sudah di terima silahkan bergabung dengan link ini untuk informasi lebih lanjut https://chat.whatsapp.com/FTioRDhADVw5tUukl9TmRw" class="btn btn-success">Kirim Pesan</a>
                                    <?php endif; ?>
                                    </td>

                                </tr>
                                <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\aplikasi_ppdb\ppdb\resources\views/pages/dashboard/index.blade.php ENDPATH**/ ?>