<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>MTs Bina Cendekia Cirebon - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Custom fonts for this template-->
   <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="bg-gradient-primary">

    <div class="container">

        <?php echo $__env->yieldContent('content'); ?>
        

    </div>

    <!-- Bootstrap core JavaScript-->
    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH D:\Laravel\PPDB_PLUS1\PPDB_SMP\resources\views/layouts/auth.blade.php ENDPATH**/ ?>