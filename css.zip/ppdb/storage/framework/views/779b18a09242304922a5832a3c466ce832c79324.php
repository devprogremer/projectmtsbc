<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <a href="/admin" class="btn btn-danger mb-5">Back</a>
    <a href="../../admin/view/<?php echo e($item ->id); ?>"><button type="button" class="btn btn-primary mb-5">View Card </button></a>
    <div class="card">
        <div class="card-body">
            <h4>Data Lengkap Peserta</h4>
            <div class="row">
                <table class="table table-bordered">
                    <tr>
                        <td>Nama</td>
                        <td><?php echo e($item->nama_siswa); ?></td>
                    </tr>
                    <tr>
                        <td>TTL</td>
                        <td><?php echo e($item-> tempat_lahir); ?>, <?php echo e($item->tanggal_lahir); ?></td>
                    </tr>
                    <tr>
                        <td>Asal Sekolah</td>
                        <td><?php echo e($item->asal_sekolah); ?></td>
                    </tr>
                    <tr>
                        <td>Alamat</td>
                        <td><?php echo e($item->Alamat); ?></td>
                    </tr>
                    <tr>
                        <td>No Telepon</td>
                        <td><?php echo e($item->no_telp); ?></td>
                    </tr>
                    <tr>
                        <td>nama ibu</td>
                        <td><?php echo e($ayah->nama_ayah); ?></td>
                    </tr>
                    <tr>
                        <td>nama ibu</td>
                        <td><?php echo e($ibu->nama_ibu); ?></td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td><?php echo e($item->gender); ?></td>
                    </tr>

                    <tr>
                        <td>Pekerjaan Ayah</td>
                        <td><?php echo e($ayah->Pekerjaan); ?></td>
                    </tr>
                    <tr>
                        <td>Pekerjaan Ibu</td>
                        <td><?php echo e($ibu->pekerjaan_ibu); ?></td>
                    </tr>
                    <tr>
                        <td>Penghasilan Ayah</td>
                        <td><?php echo e($ayah->Penghasilan); ?></td>
                    </tr>
                    
                    <tr>
                        <td>No Telepon Ortu</td>
                        <td><?php echo e($ibu->no_telp_ortu); ?></td>
                    </tr>
                    <tr>
                        <td>Status</td>
                        <td><?php echo e($item->status); ?></td>
                    </tr>
                    <tr>
                        <td>Aksi</td>
                        <td>
                            <?php if($item->status == 'MENUNGGU'): ?>
                                <form method="post" class="d-inline-block" action="<?php echo e(route('peserta-diterima', $item->id)); ?>">
                                    <?php echo method_field('PATCH'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success mr-2" href="https://wa.me/089506037357?text=Halo%20nama%20saya%20nadine">
                                        TERIMA
                                    </button>
                                </form>
                                <form method="post" class="d-inline-block" action="<?php echo e(route('peserta-ditolak', $item->id)); ?>">
                                    <?php echo method_field('PATCH'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger mr-2">
                                        TOLAK
                                    </button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-success mr-2" disabled>
                                    TERIMA
                                </button>
                                <button class="btn btn-danger mr-2" disabled>
                                    TOLAK
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PPDB_PLUS1\PPDB_SMP\resources\views/pages/dashboard/detail.blade.php ENDPATH**/ ?>