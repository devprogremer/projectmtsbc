<?php $__env->startPush('style'); ?>
<link href="<?php echo e(url('sbadmin/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">User</h1>
    <p class="mb-4">
        List data User
        <br>
        <?php if(session('pesan')): ?>
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><i class="icon fa fa-check"></i>Success</h4>
          <?php echo e(session('pesan')); ?>

        </div>
        <?php endif; ?>
    </p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Table User</h6>
        </div>
        <div class="card-body">
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-2">Tambah Data</a>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama User</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama User</th>
                            <th>Email</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $i=1 ?>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('user.edit', $item->id)); ?>" class="btn btn-success mr-2">
                                    Edit
                                </a>
                                <?php if(count($items) > 1): ?>
                                    <form method="post" class="d-inline-block" action="<?php echo e(route('user.destroy', $item->id)); ?>">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger mr-2">
                                            Delete
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>

                        </tr>
                        <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(url('sbadmin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('sbadmin/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(url('sbadmin/js/demo/datatables-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PPDB_SMP\resources\views/pages/user/index.blade.php ENDPATH**/ ?>