<footer id="footer" style="margin-top: 100px;">
    <div class="container d-md-flex py-4">

      <div class="mr-md-auto text-center text-md-left">
        <div class="copyright">
          &copy; Copyright <strong><span>MTs Bina Cendekia Cirebon</span></strong>. All Rights Reserved
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="mailto:smpmaarif06@gmail.com" class="email"><i class="icofont-envelope"></i></a>
        <a href="https://www.instagram.com/smpplusalmaarif/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://api.whatsapp.com/send?phone=6281395588070" class="whatsapp"><i class="bx bxl-whatsapp"></i></a>
    </div>
  </footer>
<?php /**PATH C:\Users\SYARIF FADILLA\Documents\PPDB_SMP\resources\views/includes/user/footer.blade.php ENDPATH**/ ?>