<?php $__env->startSection('content'); ?>
<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container">
      <div class="header-container d-flex align-items-center">
        <div class="logo mr-auto">
          <h1 class="text-light"><a href="/"><span>MTs Bina Cendekia Cirebon</span></a></h1>
          <!-- Uncomment below if you prefer to use an image logo -->
          <!-- <a href="index.html"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="" class="img-fluid"></a>-->
        </div>

        <nav class="nav-menu d-none d-lg-block">
          <ul>
            <li class="active"><a href="/">Home</a></li>
          </ul>
        </nav><!-- .nav-menu -->
      </div><!-- End Header Container -->
    </div>
  </header>
<main id="main">
    <div class="container" style="margin-top: 150px;">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <h2 class="text-center mt-5 mb-3">Tata Cara PPDB Online</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="card h-100 d-flex">
                    <div class="card-body text-center">
                        <h4>Daftar</h4>
                        <p>Calon peserta didik baru akses laman situs PPDB online</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 d-flex">
                    <div class="card-body text-center">
                        <h4>Memberikan Bukti Berkas</h4>
                        <p>Calon peserta didik mempersiapkan beberapa dokumen penting yang dibutuhkan untuk memverifikasi data</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 d-flex">
                    <div class="card-body text-center">
                        <h4>Verifikasi Data</h4>
                        <p>Operator akan melakukan verifikasi pengajuan akun dan berkas secara online</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card h-100 d-flex">
                    <div class="card-body text-center">
                        <h4>Hasil</h4>
                        <p>Calon peserta didik baru akan mengecek apakah mereka telah lulus atau tidak di halaman <strong>"Hasil Pendaftaran"</strong></p>
                    </div>
                </div>
            </div>
        </div>

                        <div class="col-12">
                            <h1 class="mt-5">Biodata Orang Tua</h1>
                            <hr>
                            <form class="" action="/ortu" method="post">

                              <?php echo csrf_field(); ?>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>Nama Orang Tua (Ayah)</label>
                                <input type="text" name="nama_ayah" class="form-control" autocomplete="off" autofocus>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pekerjaan Ayah</label>
                                <select class="form-control" name="Pekerjaan">
                                    <option value="">Pilih Pekerjaan Ayah</option>
                                    <option value="Wira Swasta">Wira Swasta</option>
                                    <option value="buruh">Buruh</option>
                                    <option value="pedagang">pedagang</option>
                                </select>



                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Penghasilan Ayah</label>
                                <select class="form-control" name="Penghasilan">
                                    <option value="">Pilih Gaji Ayah</option>
                                    <option value="1.000.000">Kurang dari 1.000.000</option>
                                    <option value=">1.000.000">Lebih dari 1.000.000</option>
                                    <option value="2.000.000">2.000.000</option>
                                    <option value=">3.000.000">Lebih dari 3.000.000</option>
                                    <option value=">4.000.000">Lebih dari 4.000.000</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>Nama Orang Tua (Ibu)</label>
                                <input type="text" name="nama_ibu" class="form-control" autocomplete="off" autofocus>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pekerjaan Ibu</label>
                                <select class="form-control" name="pekerjaan_ibu">
                                    <option value="">Pilih Pekerjaan Ibu</option>
                                    <option value="Wira Swasta">Wira Swasta</option>
                                    <option value="buruh">Buruh</option>
                                    <option value="Ibu rumah tangga">Ibu rumah tangga</option>

                                </select>

                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Penghasilan Ibu</label>
                                <select class="form-control" name="penghasilan_ibu">
                                    <option value="">Pilih Gaji Ibu</option>
                                    <option value="1.000.000">Kurang dari 1.000.000</option>
                                    <option value=">1.000.000">Lebih dari 1.000.000</option>
                                    <option value="2.000.000">2.000.000</option>
                                    <option value=">3.000.000">Lebih dari 3.000.000</option>
                                    <option value=">4.000.000">Lebih dari 4.000.000</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label>No Telepon</label>
                                <input type="text" name="no_telp_ortu" class="form-control">
                            </div>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary w-100" type="submit">Kirim</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\PPDB_SMP\resources\views/pages/user-flow/ortu.blade.php ENDPATH**/ ?>